#!/usr/bin/python2 -tt
#
# Copyright 2015 David Steele <dsteele@gmail.com>
# This file is pat of cloudprint
# Available under the terms of the GNU General Public License version 2 or later
#

import sys
import urllib
import os
import string
import json
import random

try:
    from gi.repository import Gtk
    from gi.repository import Gdk
    from gi.repository import GLib
    from gi.repository import WebKit
except ImportError:
    # graphical login optional
    pass

def mute_stderr():
    sys.stderr.flush()
    newstderr = os.dup(2)
    devnull = os.open(os.devnull, os.O_WRONLY)
    os.dup2(devnull, 2)
    os.close(devnull)
    sys.stderr = os.fdopen(newstderr, 'w')

class CPOAuth():
    """oauth mechanism per
          https://developers.google.com/accounts/docs/OAuth2InstalledApp
        example at
          http://google-mail-oauth2-tools.googlecode.com/svn/trunk/python/oauth2.py
        Eg:
          (access, refresh) = GMOauth().generate_tokens( "user@gmail.com" )
    """

    def __init__(self):
        self.auth_endpoint = "https://accounts.google.com/o/oauth2/auth"
        self.token_endpoint = "https://accounts.google.com/o/oauth2/token"
        self.scope = "https://www.googleapis.com/auth/cloudprint https://www.googleapis.com/auth/googletalk"
        self.client_id = "875709648124-9se38ubihuo24jbddog9r787rvlh42q1.apps.googleusercontent.com"
        self.client_secret = "Y2No0EPTJyYgZh0MjpdM8eMH"
        self.win_valid = False


    def get_code(self, login_hint):
        s=string.lowercase + string.uppercase + string.digits
        state = ''.join(random.sample(s,10))

        mute_stderr()

        GLib.threads_init()
        win = Gtk.Window()
        win.set_title("")
        bro = WebKit.WebView()

        args = { "response_type": "code",
             "client_id": self.client_id,
             "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
             "prompt": "consent",
             "scope": self.scope,
             "state": state,
             "login_hint": login_hint }

        code_url= "%s?%s" % (self.auth_endpoint, urllib.urlencode(args))

        bro.open(code_url)
        win.add(bro)
        win.resize(600,600)

        self.win_valid=True
        def win_closed(window, self):
           self.win_valid = False
        win.connect("destroy", win_closed, self)

        win.show_all()

        code = None
        count = 0
        while self.win_valid:
            Gtk.main_iteration_do(False)
            bro_title = bro.get_title()
            if not win.get_property("visible"):
                count += 1
                if count > 100:
                    self.win_valid = False
            if bro_title and state in bro_title:
                code = bro_title.split("=")[-1]
                win.hide()

        return code

    def get_token_dict(self, code):

        args = { "code": code,
             "client_id": self.client_id,
             "client_secret": self.client_secret,
             "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
             "grant_type": "authorization_code",
           }

        token_page = urllib.urlopen( self.token_endpoint, urllib.urlencode(args))

        return(json.loads(token_page.read()))

    def get_access_from_refresh(self, refresh_token):

        args = { "refresh_token": refresh_token,
             "client_id": self.client_id,
             "client_secret": self.client_secret,
             "grant_type": "refresh_token",
          }

        token_page = urllib.urlopen( self.token_endpoint, urllib.urlencode(args))
        token_dict = json.loads(token_page.read())

        if "access_token" in token_dict:
            return(token_dict["access_token"])
        else:
            return(None)

    def generate_tokens(self, login, refresh_token=None):
        """Generate an access token/refresh token pair for 'login' email
           account, using an optional refresh token.
           If refresh is not possible, the caller will be prompted for
           authentication via an internal browser window."""

        if refresh_token:
           access_token = self.get_access_from_refresh(refresh_token)
           if access_token:
               return( (access_token, refresh_token) )

        code = self.get_code(login)

        token_dict = self.get_token_dict(code)

        try:
            return( (token_dict["access_token"], token_dict["refresh_token"]) )
        except:
            # todo - replace with a GG exception
            return( (None, None) )

    def access_iter(self, access, refresh, login):
        if access:
            yield (access, refresh)

        if refresh:
            yield (self.get_access_from_refresh(refresh), refresh)

        yield self.generate_tokens(login)

def main():
    if len(sys.argv) != 2:
        print "Usage: %s <account name>" % sys.argv[0]
        sys.exit(-1)

    login = sys.argv[1]
    if '@' not in login:
        login += '@gmail.com'

    oauth = CPOAuth()
    access, refresh = oauth.generate_tokens(login)

    print("%s\n%s\n%s" % (login, access, refresh))

if __name__ == '__main__':
    main()

